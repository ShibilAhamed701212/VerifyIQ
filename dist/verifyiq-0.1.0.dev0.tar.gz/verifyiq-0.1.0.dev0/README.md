# VerifyIQ — Automated Damage Claim Verification

[![Tests](https://github.com/verifyiq/verifyiq/actions/workflows/tests.yml/badge.svg)](https://github.com/verifyiq/verifyiq/actions/workflows/tests.yml)
[![Tests](https://img.shields.io/badge/tests-58%2F58-green)]()
[![Static Accuracy](https://img.shields.io/badge/static%20accuracy-100%25-brightgreen)]()
[![Python](https://img.shields.io/badge/python-3.12-blue)]()
[![License](https://img.shields.io/badge/license-MIT-green)]()

---

## Overview

VerifyIQ is a modular, deterministic AI system that automates damage claim verification. It analyzes submitted images and claim conversations, extracts visual evidence using Google Gemini, and applies a strict rule engine to determine whether a claim is supported, contradicted, or requires more information.

The system is designed for **reliability, reproducibility, and explainability** — every decision has a traceable justification, every component has a fallback, and identical inputs always produce identical outputs.

---

## Problem

Manual damage claim verification is:

- **Slow** — Each claim requires human review of images and text
- **Inconsistent** — Different reviewers make different decisions
- **Expensive** — Expert review costs scale linearly with volume
- **Non-transparent** — Claimants don't understand why decisions were made

Automated verification must match or exceed human accuracy while being faster, cheaper, and fully transparent.

---

## Design Philosophy

| Principle | Implementation |
|-----------|---------------|
| **Deterministic where possible** | Rule engine, risk analyzer, severity engine — all pure functions |
| **AI as sensor, not judge** | Gemini extracts visual *facts*; rules make *decisions* |
| **Zero crashes** | Every component wrapped in try/catch with sensible fallbacks |
| **Explainable by design** | Every output includes a human-readable justification trace |
| **Testable at every level** | Each component independently unit-testable |

---

## Architecture

```
                         ┌─────────────────────┐
                         │   Input Claims.csv   │
                         └──────────┬──────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │   Image Loader &    │
                         │    Validator        │
                         │  (size, format,     │
                         │   corruption check) │
                         └──────────┬──────────┘
                                    │
                         ┌─────────────────────┐
                         │  Image Normalizer   │
                         │ (AVIF/WebP/PNG→JPEG)│
                         └──────────┬──────────┘
                                    │
                         ┌─────────────────────┐
                         │  Claim Parser       │
                         │ (keyword + negation)│
                         └──────────┬──────────┘
                                    │
              ┌─────────────────────┼─────────────────────┐
              │                     │                     │
              ▼                     ▼                     ▼
     ┌────────────────┐   ┌────────────────┐   ┌────────────────┐
     │  Gemini Vision │   │  User History  │   │  CV Modules    │
     │  (observation  │   │  (fraud risk)  │   │ (blur, crop,   │
     │   extraction)  │   │                │   │  OCR, object)  │
     └────────┬───────┘   └────────┬───────┘   └────────┬───────┘
              │                     │                     │
              └──────────┬──────────┴──────────┬──────────┘
                         │                     │
                         ▼                     ▼
              ┌────────────────┐   ┌────────────────┐
              │ Evidence       │   │ Rule Engine    │
              │ Checker        │   │ (6 decision    │
              │ (requirements) │   │  paths)        │
              └────────┬───────┘   └────────┬───────┘
                       │                    │
                       └──────────┬─────────┘
                                  │
                                  ▼
                    ┌─────────────────────────┐
                    │   Risk Analyzer         │
                    │ (15+ risk flag sources) │
                    └────────────┬────────────┘
                                 │
                    ┌─────────────────────────┐
                    │   Severity Engine       │
                    │ (static + boost words)  │
                    └────────────┬────────────┘
                                 │
                    ┌─────────────────────────┐
                    │   Output Validator      │
                    │ (schema + consistency)  │
                    └────────────┬────────────┘
                                 │
                    ┌─────────────────────────┐
                    │   Submission Critic     │
                    │ (post-processing check) │
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │   Output.csv            │
                    └─────────────────────────┘
```

---

## Pipeline

The pipeline processes each claim through 11 stages:

| Stage | Component | What It Does |
|-------|-----------|-------------|
| 1 | Image Loader | Parses CSV image paths, resolves relative paths |
| 2 | Image Validator | Checks size (<10MB), format, PIL decode integrity |
| 3 | Image Normalizer | Converts AVIF/WebP/PNG/BMP to JPEG |
| 4 | Claim Parser | Extracts claimed damage type and object part from conversation text, handles negation |
| 5 | Vision Analyzer | Calls Gemini to extract per-image observations: damage type, visible parts, quality metrics |
| 6 | Evidence Checker | Evaluates whether images meet evidence requirements for the claim |
| 7 | Rule Engine | Applies 6-path decision tree: support, contradict, or insufficient evidence |
| 8 | Risk Analyzer | Computes risk flags from vision, rules, CV modules, and user history |
| 9 | Severity Engine | Maps damage type + claim context to severity (none/low/medium/high) |
| 10 | Output Validator | Validates schema, enums, and output consistency (catches contradictions) |
| 11 | Submission Critic | Post-processing check for missing flags, critical patterns |

---

## Features

### Core Verification
- Damage type classification (dent, scratch, crack, glass_shatter, water_damage, stain, torn/crushed packaging, broken/missing parts)
- Object part identification (car parts, laptop components, package regions)
- Evidence requirement checking against configurable rules
- Severity assessment with context-aware boosting

### Reliability
- **Safe Mode**: Every component wrapped in try/catch. If Gemini fails, the pipeline continues with degraded output
- **Gemini Cache**: SHA-256 hash-based response cache. Identical inputs = identical outputs
- **OCR Safe Mode**: When Tesseract is unavailable, returns "no text" for all images — gracefully, not crash
- **Image Validation**: Rejects oversized (>10MB) or corrupt images before processing
- **Fallback Output**: Every error path produces a valid output row with manual_review_required flag

### Explainability
- Every output includes a `claim_status_justification` trace showing the reasoning chain
- Risk flags document specific concerns (blurry_image, wrong_object, low_light, etc.)
- Severity decisions reference specific damage type and boost keywords

### Fraud Detection
- User history analysis (claim frequency, rejection rate)
- Wrong object detection via CV module
- Non-original image detection (screenshots, stock photos)
- Cross-image conflict detection (inconsistent damage across images)

---

## Evaluation

| Metric | Static Evaluation | Live Evaluation |
|--------|------------------|-----------------|
| Accuracy | 20/20 (100%) | ~70% |
| Claims | 20 (with ideal vision) | 20 (with Gemini vision) |
| Runtime | ~5 seconds | ~3-5 minutes |
| API calls | 0 | 20 |

**Static evaluation** injects ideal vision results to test the deterministic pipeline in isolation.

**Live evaluation** calls the Gemini API for each claim and compares all 7 output fields against expected values. Compatible damage types (crack↔glass_shatter, stain↔water_damage) are treated as matches.

---

## Testing

```
tests/
├── test_parser.py           # ClaimParser negation, keyword matching
├── test_rule_engine.py      # RuleEngine 6 decision paths, compatible types
├── test_risk_flags.py       # Risk flag whitelist validation
├── test_cv.py               # Blur, crop, object detection
├── test_utils.py            # Text extraction utilities
├── test_validator.py        # Output consistency checks
├── test_critic.py           # Submission post-processing
└── test_image_validator.py  # Image validation logic

Total: 58 tests — all passing
```

---

## Results

From the competition evaluation on 20 sample claims:

| Status | Claims |
|--------|--------|
| Supported | 10 |
| Contradicted | 9 |
| Not Enough Information | 1 |

From production processing on 44 actual claims:
- 44/44 claims processed (100% completion)
- 1 degraded output (user_047 — Gemini 503 error caught by Safe Mode)
- ~0:06:00 runtime at ~$0.01 API cost

---

## Project Structure

```
verifyiq/
├── code/                        # Core pipeline (frozen)
│   ├── main.py                  # Entry point
│   ├── claim_processor.py       # Orchestrator
│   ├── claim_parser.py          # Text parser
│   ├── vision_analyzer.py       # Gemini client
│   ├── evidence_checker.py      # Evidence rules
│   ├── rule_engine.py           # Decision engine
│   ├── risk_analyzer.py         # Risk computation
│   ├── severity_engine.py       # Severity mapping
│   ├── decision_agent.py        # Output assembly
│   ├── output_validator.py      # Schema validation
│   ├── submission_critic.py     # Post-processing
│   ├── image_preprocessor.py    # Format conversion
│   ├── image_validator.py       # Image validation
│   ├── config.py                # Configuration
│   ├── prompts.py               # Gemini prompts
│   ├── utils.py                 # Helpers
│   ├── cv/                      # Computer vision
│   │   ├── blur_detector.py
│   │   ├── crop_detector.py
│   │   ├── text_detector.py
│   │   └── object_validator.py
│   ├── tests/                   # Unit tests
│   └── evaluation/              # Evaluation pipeline
│       ├── evaluate.py
│       ├── static_evaluate.py
│       └── error_analysis.py
├── dataset/                     # Input data
├── docs/                        # Documentation
│   ├── ARCHITECTURE.md
│   ├── EVALUATION.md
│   ├── RELIABILITY.md
│   ├── SECURITY.md
│   ├── REPRODUCIBILITY.md
│   ├── ADVERSARIAL_TESTING.md
│   ├── JUDGE_INTERVIEW.md
│   └── WINNING_REVIEW.md
├── reports/                     # Evaluation reports & reviews
│   ├── FINAL_REVIEW.md          # Multi-persona final review
│   ├── FINAL_VERDICT.md         # Weighted score & ranking
│   ├── TREE_AUDIT.md            # File tree audit
│   ├── ORGANIZATION_REVIEW.md   # Organization review
│   ├── winning_report.md        # Winning analysis
│   ├── executive_scorecard.md   # Executive dash scorecard
│   ├── security_report.md       # Security assessment
│   ├── reproducibility_report.md# Reproducibility audit
│   ├── adversarial_report.md    # Adversarial testing results
│   ├── competitor_report.md     # Competitor analysis
│   ├── scalability_report.md    # Throughput & cost estimates
│   ├── architecture_review.md   # Architecture decision review
│   └── PROJECT_FLOW_REPORT.md   # Project flow overview
├── development/                 # Development context (preserved)
│   ├── CLAUDE.md                # Agent instructions (frozen)
│   └── AGENT_HISTORY.log        # Session history
├── archive/                     # Reference materials (preserved)
│   ├── challenge_instructions_extracted.txt
│   ├── ARCHITECTURE.md          # Superseded by docs/
│   └── judge_interview.md       # Superseded by docs/
├── adversarial_evaluation/      # Adversarial testing artifacts
├── submission/                  # Judge submission package
├── README.md                    # This file
├── AGENTS.md                    # Agent orchestration rules
├── problem_statement.md         # Challenge description
├── ATTRIBUTIONS.md              # Licenses & attributions
├── PROJECT_IDENTITY.md          # Project philosophy
└── requirements.txt
```

---

## Quick Start

```bash
# Install dependencies
pip install google-genai Pillow tqdm

# Set your Gemini API key
export GEMINI_API_KEY="your-key-here"

# Process claims and produce output
python code/main.py

# Run evaluation on sample claims
python -m code.evaluation.evaluate

# Run tests
python -m pytest code/tests/
```

---

## Future Work

- **Multi-model vision**: Add GPT-4o or open-source VLM as secondary observer for comparison
- **Parallel batch processing**: Process multiple claims concurrently with rate-limit awareness
- **Confidence-based severity**: Replace static severity with confidence-weighted dynamic mapping
- **Cross-claim fraud detection**: Link claims from the same user to detect patterns
- **Real-time processing**: Optimize for sub-second claim verification at scale
- **Self-improving rules**: Learn optimal thresholds from evaluation feedback

---

## License

MIT License. See `ATTRIBUTIONS.md` for third-party license details.

**Third-party dependencies:**
- `google-genai` — Apache 2.0
- `Pillow` — Historical BSD-like
- `opencv-python` — MIT
- `pytesseract` — Apache 2.0
- `pytest` — MIT
